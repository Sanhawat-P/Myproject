document.addEventListener("DOMContentLoaded", async () => {
    const languageSelector = document.getElementById("languageSelector");

    if (!languageSelector) {
        console.warn("Language selector not found!");
        return;
    }

    // Fetch translations once and store them
    let translations = {};

    try {
        const response = await fetch("/translations.json"); // Use absolute path if needed
        if (!response.ok) throw new Error("Failed to load translations.");
        translations = await response.json();
    } catch (error) {
        console.error("Error loading translations:", error);
        return;
    }

    // Function to update text content safely
    function updateTextContent(lang) {
        if (!translations[lang]) {
            console.warn(`No translations found for language: ${lang}`);
            return;
        }

        const textMapping = {
            "index-welcome": "welcome",
            "index-loginText": "login",
            "index-signupText": "signup",

            "login-login1": "login",
            "login-login2": "login",
            "login-noAccount" : "noAccount",
            "login-signup" : "signup",

            "signup-signup1" : "signup",
            "signup-signup2" : "signup",
            "signup-already" : "already",

            "movie-selectAMovie": "selectAMovie",
            "movie-selectShowtime1": "selectShowtime",
            "movie-selectShowtime2": "selectShowtime",
            "movie-selectShowtime3": "selectShowtime",
            "movie-book1": "book",
            "movie-book2": "book",
            "movie-book3": "book",

            "book-bookMovieTicket" : "bookMovieTicket",
            "book-showTime1" : "showTime",
            "book-summary" : "summary",
            "book-movie" : "movie",
            "book-showTime2" : "showTime",
            "book-seat" : "seat",
            "book-price" : "price",
            "book-confirm" : "confirm"
        };

        Object.keys(textMapping).forEach((id) => {
            const element = document.getElementById(id);
            if (element) {
                element.textContent = translations[lang][textMapping[id]] || `Missing: ${textMapping[id]}`;
            }
        });
    }

    // Apply translations on page load
    updateTextContent(languageSelector.value);

    // Listen for language selection changes
    languageSelector.addEventListener("change", (event) => {
        updateTextContent(event.target.value);
    });
});