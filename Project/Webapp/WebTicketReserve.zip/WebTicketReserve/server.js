const express = require("express");
const bodyParser = require("body-parser");
const session = require("express-session");
const fs = require("fs");
const path = require("path");

const app = express();
const PORT = 3000;

app.use(express.static(path.join(__dirname, 'public')));

// ตั้งค่า Express session
app.use(
  session({
    secret: "secret_key",
    resave: false,
    saveUninitialized: true,
  })
);

// ตั้งค่า body-parser เพื่อรับข้อมูลจากฟอร์ม
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

// ไฟล์ JSON ที่เก็บข้อมูลผู้ใช้และการจอง
const usersFile = path.join(__dirname, "users.json");
const bookingsFile = path.join(__dirname, "bookings.json");

// ฟังก์ชันในการอ่านไฟล์ JSON
function readJSONFile(filePath) {
  try {
    const data = fs.readFileSync(filePath);
    return JSON.parse(data);
  } catch (err) {
    return [];
  }
}

// ฟังก์ชันในการเขียนข้อมูลลงไฟล์ JSON
function writeJSONFile(filePath, data) {
  fs.writeFileSync(filePath, JSON.stringify(data, null, 2));
}

// หน้าแรก
app.get("/", (req, res) => {
  res.sendFile(path.join(__dirname, "public", "index.html"));
});

// หน้า Login
app.get("/login", (req, res) => {
  res.sendFile(path.join(__dirname, "public", "login.html"));
});

// หน้า Signup
app.get("/signup", (req, res) => {
  res.sendFile(path.join(__dirname, "public", "signup.html"));
});

// หน้าเลือกหนัง
app.get("/movie", (req, res) => {
  res.sendFile(path.join(__dirname, "public", "movie.html"));
});

// หน้า Book
app.get("/book", (req, res) => {
  res.sendFile(path.join(__dirname, "public", "book.html"));
});

// ตรวจสอบที่นั่งที่ถูกจองแล้วสำหรับหนังและรอบฉาย
app.get("/booked-seats", (req, res) => {
  const { movie, showtime } = req.query;
  const bookings = readJSONFile(bookingsFile);

  // หาที่นั่งที่จองแล้วสำหรับหนังที่เลือกและรอบฉายที่เลือก
  const bookedSeats = bookings
    .filter(booking => booking.movieTitle === movie && booking.showtime === showtime)
    .flatMap(booking => booking.selectedSeats);

  res.json(bookedSeats);
});

// การสมัครสมาชิก
app.post("/signup", (req, res) => {
  const { username, password } = req.body;
  const users = readJSONFile(usersFile);

  if (users.find((user) => user.username === username)) {
    return res.status(400).send("User already exists.");
  }

  const newUser = { username, password };
  users.push(newUser);
  writeJSONFile(usersFile, users);

  res.redirect("/login");
});

// การล็อกอิน
app.post("/login", (req, res) => {
  const { username, password } = req.body;
  const users = readJSONFile(usersFile);

  const user = users.find(
    (user) => user.username === username && user.password === password
  );

  if (!user) {
    return res.status(400).send("Invalid username or password.");
  }

  req.session.loggedIn = true;
  req.session.username = username;
  req.session.isAdmin = user.isAdmin || false;  // เพิ่มการตรวจสอบว่าเป็นแอดมินหรือไม่
  if (user.isAdmin) {
    res.redirect("/admin/show-booking");  // เปลี่ยนเส้นทางไปยังหน้า show booking
  } else {
    res.redirect("/movie");  // ถ้าไม่ใช่แอดมิน ให้ไปหน้าเลือกหนัง
  }
});

// การจองตั๋ว
app.post("/book", (req, res) => {
  const { selectedSeats, movieTitle, showtime } = req.body;

  // ตรวจสอบว่า session ผู้ใช้ล็อกอินอยู่หรือไม่
  const customerName = req.session.username;
  if (!customerName) {
    return res.status(401).send("You need to be logged in to make a booking.");
  }

  const bookings = readJSONFile(bookingsFile);
  // คำนวณราคาตั๋ว
  const totalPrice = selectedSeats.split(', ').length * 200;  // ราคาต่อที่นั่ง = 200

  const newBooking = {
    customerName,
    movieTitle,
    showtime,
    selectedSeats: selectedSeats.split(', '),
    totalPrice,
    date: new Date(),
  };

  bookings.push(newBooking);
  writeJSONFile(bookingsFile, bookings);

  res.redirect("/movie");
});

// Route ที่จะไปหน้า showbooking.html
app.get("/admin/show-booking", (req, res) => {
  if (!req.session.loggedIn || !req.session.isAdmin) {
    return res.status(403).send("You are not authorized to view this page.");
  }

  // ส่งข้อมูลการจองไปยัง showbooking.html
  res.sendFile(path.join(__dirname, "public", "showbooking.html"));
});

// Route สำหรับส่งข้อมูลการจองในรูปแบบ JSON
app.get('/api/bookings', (req, res) => {
  // อ่านข้อมูลการจองจากไฟล์ bookings.json
  const bookings = readJSONFile(bookingsFile);
  res.json(bookings); // ส่งข้อมูลกลับเป็น JSON
});

// เริ่มเซิร์ฟเวอร์
app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});
